import React, { useEffect } from 'react';
import { StyleSheet, View } from 'react-native';
import Animated, {
  Easing,
  Extrapolate,
  interpolate,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
} from 'react-native-reanimated';

export function AnimatedRippleRings({
  color = '#1A4D8F',
  sizes = [64, 88, 112, 136, 160, 184, 208],
  style,
  children,
}) {
  const animationValue = useSharedValue(0);

  useEffect(() => {
    animationValue.value = withRepeat(
      withTiming(1, {
        duration: 3000,
        easing: Easing.out(Easing.quad),
      }),
      -1,
      false
    );
  }, [animationValue]);

  return (
    <View style={[styles.container, style]}>
      {sizes.map((size, index) => (
        <RippleRing
          key={index}
          size={size}
          color={color}
          animationValue={animationValue}
          delay={index * 100}
        />
      ))}
      {children ? <View style={styles.children}>{children}</View> : null}
    </View>
  );
}

function RippleRing({ size, color, animationValue, delay }) {
  const animatedStyle = useAnimatedStyle(() => {
    const delayFactor = delay / 700;
    const adjustedValue = interpolate(
      animationValue.value + delayFactor,
      [0, 1],
      [0, 1],
      Extrapolate.CLAMP
    );

    const opacity = interpolate(
      adjustedValue,
      [0, 0.5, 1],
      [0.8, 0.4, 0],
      Extrapolate.CLAMP
    );

    const scale = interpolate(
      adjustedValue,
      [0, 1],
      [0.5, 1.5],
      Extrapolate.CLAMP
    );

    return {
      opacity,
      transform: [{ scale }],
    };
  });

  return (
    <Animated.View
      style={[
        styles.ring,
        {
          width: size,
          height: size,
          borderRadius: size / 2,
          borderColor: color,
        },
        animatedStyle,
      ]}
    />
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  ring: {
    position: 'absolute',
    borderWidth: 1,
  },
  children: {
    zIndex: 10,
  },
});
