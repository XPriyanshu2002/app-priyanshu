import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';

import { DashboardLogo } from './dashboard-logo';

export function DashboardOverviewSection({ data, onOpenMenu, onOpenNotifications, theme }) {
  return (
    <View style={styles.section}>
      <View style={styles.headerRow}>
        <TouchableOpacity
          style={[
            styles.headerButton,
            styles.headerButtonLeft,
            { backgroundColor: theme.topButtonSurface, shadowColor: theme.shadowColor },
          ]}
          activeOpacity={0.85}
          onPress={onOpenMenu}>
          <MaterialIcons name="menu" size={20} color={theme.topButtonIcon} />
        </TouchableOpacity>

        <View pointerEvents="none" style={styles.headerLogoWrap}>
          <DashboardLogo width={38} height={36} />
        </View>

        <TouchableOpacity
          style={[
            styles.headerButton,
            styles.headerButtonRight,
            { backgroundColor: theme.topButtonSurface, shadowColor: theme.shadowColor },
          ]}
          activeOpacity={0.85}
          onPress={onOpenNotifications}>
          <MaterialIcons name="notifications-none" size={20} color={theme.topButtonIcon} />
        </TouchableOpacity>
      </View>

      <Text style={[styles.greeting, { color: theme.dashboardText }]}>{data.greeting}</Text>
      <Text style={[styles.subheading, { color: theme.dashboardSubtext }]}>{data.subheading}</Text>

      <View style={[styles.dueCard, { backgroundColor: theme.dueCard }]}>
        <Text style={[styles.dueAmount, { color: theme.dueText }]}>{data.dueAmount}</Text>
        <Text style={[styles.dueDate, { color: theme.dueDate }]}>{data.dueDate}</Text>
      </View>

      <View style={[styles.payCard, { backgroundColor: theme.payCard }]}>
        <View style={styles.payIconWrap}>
          <MaterialIcons name="public" size={24} color={theme.payText} />
        </View>

        <View style={styles.payCopy}>
          <Text style={[styles.payTitle, { color: theme.payText }]}>{data.paymentTitle}</Text>
          <Text style={[styles.payHint, { color: theme.paySubtext }]}>{data.paymentHint}</Text>
        </View>

        <TouchableOpacity style={[styles.payNowButton, { backgroundColor: theme.payButtonBg }]} activeOpacity={0.9}>
          <Text style={[styles.payNowText, { color: theme.payButtonText }]}>Pay Now</Text>
        </TouchableOpacity>

        <Text style={[styles.daysLeft, { color: theme.paySubtext }]}>{data.daysLeft}</Text>
      </View>

      <View style={[styles.connectionCard, { backgroundColor: theme.connectionCard }]}>
        <View style={[styles.connectionIcon, { borderColor: theme.connectionBorder }]}>
          <MaterialIcons name="wifi-tethering" size={18} color={theme.payText} />
        </View>

        <View style={styles.connectionCopy}>
          <Text style={[styles.connectionTitle, { color: theme.payText }]}>{data.connectionTitle}</Text>
          <Text style={[styles.connectionLabel, { color: theme.payText }]}>{data.connectionLabel}</Text>
        </View>

        <View style={styles.connectionMeta}>
          <View style={[styles.statusPill, { backgroundColor: theme.statusPill }]}>
            <Text style={styles.statusPillText}>{data.connectionStatus}</Text>
          </View>

          <View style={styles.numberRow}>
            <MaterialIcons name="signal-cellular-alt" size={18} color={theme.summaryAccent} />
            <Text style={[styles.connectionNumber, { color: theme.payText }]}>{data.connectionNumber}</Text>
          </View>

          <Text style={[styles.connectionDate, { color: theme.dueDate }]}>{data.connectionDate}</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  section: {
    rowGap: 6,
  },
  headerRow: {
    height: 46,
    position: 'relative',
    marginBottom: 8,
  },
  headerButton: {
    position: 'absolute',
    top: 0,
    width: 39,
    height: 39,
    borderRadius: 20,
    backgroundColor: '#FBFCFA',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#0A170B',
    shadowOpacity: 0.06,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
    elevation: 2,
  },
  headerButtonLeft: {
    left: 0,
  },
  headerButtonRight: {
    right: 0,
  },
  headerLogoWrap: {
    position: 'absolute',
    top: 3,
    left: 0,
    right: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
  greeting: {
    color: '#283028',
    fontSize: 20,
    lineHeight: 26,
    fontWeight: '700',
    marginTop: 6,
  },
  subheading: {
    color: '#667066',
    fontSize: 11,
    lineHeight: 16,
    marginBottom: 8,
  },
  dueCard: {
    minHeight: 38,
    borderRadius: 4,
    backgroundColor: '#24478E',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
  },
  dueAmount: {
    color: '#FFFFFF',
    fontSize: 12,
    lineHeight: 16,
    fontWeight: '500',
  },
  dueDate: {
    color: '#D7E5FF',
    fontSize: 9.5,
    lineHeight: 12,
  },
  payCard: {
    minHeight: 92,
    borderRadius: 4,
    backgroundColor: '#5BBC6E',
    paddingHorizontal: 14,
    paddingVertical: 13,
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  payIconWrap: {
    paddingTop: 4,
    marginRight: 12,
  },
  payCopy: {
    flex: 1,
  },
  payTitle: {
    color: '#FFFFFF',
    fontSize: 17,
    lineHeight: 22,
    fontWeight: '700',
  },
  payHint: {
    color: '#E7F8E9',
    fontSize: 10,
    lineHeight: 14,
    marginTop: 4,
  },
  payNowButton: {
    marginLeft: 10,
    borderRadius: 5,
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 16,
    paddingVertical: 10,
    alignSelf: 'center',
  },
  payNowText: {
    color: '#494949',
    fontSize: 11,
    lineHeight: 14,
    fontWeight: '500',
  },
  daysLeft: {
    position: 'absolute',
    right: 17,
    bottom: 11,
    color: '#E5FAE9',
    fontSize: 9,
    lineHeight: 12,
  },
  connectionCard: {
    minHeight: 94,
    borderRadius: 4,
    backgroundColor: '#24478E',
    flexDirection: 'row',
    alignItems: 'flex-start',
    paddingHorizontal: 12,
    paddingVertical: 12,
  },
  connectionIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.75)',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 2,
  },
  connectionCopy: {
    flex: 1,
    marginLeft: 10,
  },
  connectionTitle: {
    color: '#FFFFFF',
    fontSize: 14,
    lineHeight: 18,
    fontWeight: '700',
  },
  connectionLabel: {
    color: '#FFFFFF',
    fontSize: 8.5,
    lineHeight: 11,
    fontWeight: '700',
    marginTop: 20,
  },
  connectionMeta: {
    alignItems: 'flex-end',
    marginLeft: 10,
  },
  statusPill: {
    minHeight: 22,
    borderRadius: 999,
    backgroundColor: '#64C06B',
    paddingHorizontal: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  statusPillText: {
    color: '#F7FFF8',
    fontSize: 7.5,
    lineHeight: 10,
    fontWeight: '600',
  },
  numberRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 18,
  },
  connectionNumber: {
    color: '#FFFFFF',
    fontSize: 13,
    lineHeight: 17,
    fontWeight: '700',
    marginLeft: 4,
  },
  connectionDate: {
    color: '#D7E5FF',
    fontSize: 7.5,
    lineHeight: 10,
    marginTop: 4,
  },
});
