import { Image } from 'expo-image';
import { StyleSheet, View } from 'react-native';

export function DashboardLogo({ width = 36, height = 34 }) {
  return (
    <View style={[styles.wrap, { width, height }]}>
      <Image
        source={require('../../assets/images/Vector.png')}
        style={[
          styles.base,
          {
            width: width * 0.78,
            height: height * 0.76,
            left: width * 0.01,
            top: height * 0.12,
          },
        ]}
        contentFit="contain"
      />
      <Image
        source={require('../../assets/images/Vector (2).png')}
        style={[
          styles.dot,
          {
            width: width * 0.18,
            height: height * 0.2,
            right: width * 0.12,
            top: height * 0.07,
          },
        ]}
        contentFit="contain"
      />
      <Image
        source={require('../../assets/images/Vector (1).png')}
        style={[
          styles.wedge,
          {
            width: width * 0.18,
            height: height * 0.24,
            right: width * 0.08,
            bottom: height * 0.08,
          },
        ]}
        contentFit="contain"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    position: 'relative',
  },
  base: {
    position: 'absolute',
  },
  dot: {
    position: 'absolute',
  },
  wedge: {
    position: 'absolute',
  },
});
