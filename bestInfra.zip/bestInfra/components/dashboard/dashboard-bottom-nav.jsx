import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { StyleSheet, Text, View } from 'react-native';

export function DashboardBottomNav({ items, bottomInset, theme }) {
  if (!items.length) {
    return null;
  }

  return (
    <View
      style={[
        styles.nav,
        {
          paddingBottom: bottomInset + 8,
          backgroundColor: theme.navBackground,
          shadowColor: theme.shadowColor,
        },
      ]}>
      {items.map((item) => (
        <View key={item.id} style={styles.navItem}>
          <View
            style={[
              styles.iconWrap,
              { backgroundColor: theme.navIconBg },
              item.active && [styles.iconWrapActive, { backgroundColor: theme.navIconActiveBg }],
            ]}>
            <MaterialIcons name={item.icon} size={18} color={item.active ? '#FFFFFF' : theme.summaryAccent} />
          </View>
          <Text style={[styles.label, { color: theme.navLabel }, item.active && { color: theme.navLabelActive }]}>
            {item.label}
          </Text>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  nav: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 26,
    borderTopRightRadius: 26,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingTop: 12,
    paddingHorizontal: 12,
    shadowColor: '#0A170B',
    shadowOpacity: 0.08,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: -4 },
    elevation: 8,
  },
  navItem: {
    width: '20%',
    alignItems: 'center',
  },
  iconWrap: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#F6F8F5',
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconWrapActive: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: '#59B86E',
  },
  label: {
    color: '#6A6F6A',
    fontSize: 10,
    lineHeight: 13,
    marginTop: 7,
  },
});
