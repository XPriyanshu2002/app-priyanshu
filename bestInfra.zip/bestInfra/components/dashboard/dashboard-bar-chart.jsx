import { useMemo, useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { BarChart } from 'react-native-chart-kit';

const CHART_HEIGHT = 176;
const MIN_WIDTH = 280;

export function DashboardBarChart({ bars = [], barColor, labelColor }) {
  const [chartWidth, setChartWidth] = useState(0);

  const data = useMemo(
    () => ({
      labels: bars.map((bar) => bar.month),
      datasets: [{ data: bars.map((bar) => Number(bar.height) || 0) }],
    }),
    [bars]
  );

  const resolvedWidth = Math.max(MIN_WIDTH, Math.round(chartWidth || MIN_WIDTH));

  return (
    <View
      style={styles.container}
      onLayout={({ nativeEvent }) => {
        setChartWidth(nativeEvent.layout.width);
      }}>
      <BarChart
        data={data}
        width={resolvedWidth}
        height={CHART_HEIGHT}
        fromZero
        withHorizontalLabels={false}
        withInnerLines={false}
        showBarTops={false}
        yAxisLabel=""
        yAxisSuffix=""
        chartConfig={{
          backgroundColor: '#00000000',
          backgroundGradientFrom: '#00000000',
          backgroundGradientTo: '#00000000',
          decimalPlaces: 0,
          barPercentage: 0.5,
          color: () => barColor,
          fillShadowGradient: barColor,
          fillShadowGradientOpacity: 1,
          labelColor: () => labelColor,
          propsForBackgroundLines: { stroke: 'transparent' },
          propsForLabels: { fontSize: 8, fontWeight: '400' },
        }}
        style={styles.chart}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    minHeight: CHART_HEIGHT,
    justifyContent: 'flex-end',
  },
  chart: {
    marginLeft: -26,
  },
});
