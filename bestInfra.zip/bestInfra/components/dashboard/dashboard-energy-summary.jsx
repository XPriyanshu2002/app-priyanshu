import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import DateTimePicker from '@react-native-community/datetimepicker';
import { useMemo, useState } from 'react';
import { Modal, Platform, StyleSheet, Text, TouchableOpacity, View } from 'react-native';

import { DashboardBarChart } from './dashboard-bar-chart';

function formatPickedDate(date) {
  return new Intl.DateTimeFormat('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  }).format(date);
}

export function DashboardEnergySummary({ data, theme }) {
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [selectedDate, setSelectedDate] = useState(null);
  const [iosDraftDate, setIosDraftDate] = useState(new Date());

  const dateActionLabel = useMemo(
    () => (selectedDate ? formatPickedDate(selectedDate) : data.cta),
    [data.cta, selectedDate]
  );

  const openDatePicker = () => {
    const nextDate = selectedDate || new Date();
    setIosDraftDate(nextDate);
    setShowDatePicker(true);
  };

  const closeDatePicker = () => {
    setShowDatePicker(false);
  };

  const onAndroidDateChange = (event, value) => {
    setShowDatePicker(false);

    if (event.type === 'set' && value) {
      setSelectedDate(value);
    }
  };

  const onIosDateChange = (_event, value) => {
    if (value) {
      setIosDraftDate(value);
    }
  };

  const onConfirmIosDate = () => {
    setSelectedDate(iosDraftDate);
    setShowDatePicker(false);
  };

  return (
    <View style={styles.section}>
      <View style={styles.headerRow}>
        <Text style={[styles.title, { color: theme.sectionTitle }]}>{data.title}</Text>
        <TouchableOpacity style={styles.dateAction} activeOpacity={0.85} onPress={openDatePicker}>
          <Text style={[styles.dateActionText, { color: theme.sectionAction }]}>{dateActionLabel}</Text>
          <MaterialIcons name="calendar-month" size={17} color={theme.sectionAction} />
        </TouchableOpacity>
      </View>

      <View style={[styles.card, { backgroundColor: theme.summaryCard }]}>
        <View style={styles.topRow}>
          <View>
            <Text style={[styles.usageLabel, { color: theme.summaryText }]}>{data.usageLabel}</Text>
            <View style={styles.usageRow}>
              <Text style={[styles.usageValue, { color: theme.summaryAccent }]}>{data.usageValue}</Text>
              <View style={[styles.deltaPill, { backgroundColor: theme.summaryAccent }]}>
                <Text style={styles.deltaText}>{data.usageDelta}</Text>
                <MaterialIcons name={data.usageDeltaIcon} size={11} color="#FFFFFF" />
              </View>
              <Text style={[styles.comparisonText, { color: theme.summarySubtext }]}>{data.usageComparison}</Text>
            </View>
          </View>

          <TouchableOpacity style={[styles.chartButton, { backgroundColor: theme.summaryAccent }]} activeOpacity={0.85}>
            <Text style={styles.chartButtonText}>{data.chartAction}</Text>
            <MaterialIcons name="expand-more" size={16} color="#FFFFFF" />
          </TouchableOpacity>
        </View>

        <View style={styles.rangeRow}>
          {data.ranges.map((range) =>
            range === data.activeRange ? (
              <View key={range} style={[styles.activeRangePill, { backgroundColor: theme.summaryBarActive }]}>
                <Text style={styles.activeRangeText}>{range}</Text>
              </View>
            ) : (
              <Text key={range} style={[styles.rangeText, { color: theme.textMuted }]}>
                {range}
              </Text>
            )
          )}
        </View>

        <View style={styles.chartWrap}>
          <DashboardBarChart bars={data.bars} barColor={theme.summaryBar} labelColor={theme.textMuted} />
        </View>
      </View>

      {showDatePicker && Platform.OS === 'android' ? (
        <DateTimePicker
          value={selectedDate || new Date()}
          mode="date"
          display="calendar"
          onChange={onAndroidDateChange}
        />
      ) : null}

      {showDatePicker && Platform.OS === 'ios' ? (
        <Modal transparent animationType="fade" visible onRequestClose={closeDatePicker}>
          <View style={styles.dateModalBackdrop}>
            <View style={[styles.dateModalCard, { backgroundColor: theme.panelSurface }]}>
              <View style={styles.dateModalActions}>
                <TouchableOpacity onPress={closeDatePicker} style={styles.dateActionButton} activeOpacity={0.85}>
                  <Text style={[styles.dateActionButtonText, { color: theme.textMuted }]}>Cancel</Text>
                </TouchableOpacity>

                <TouchableOpacity onPress={onConfirmIosDate} style={styles.dateActionButton} activeOpacity={0.85}>
                  <Text style={[styles.dateActionButtonText, { color: theme.summaryAccent }]}>Done</Text>
                </TouchableOpacity>
              </View>

              <DateTimePicker value={iosDraftDate} mode="date" display="inline" onChange={onIosDateChange} />
            </View>
          </View>
        </Modal>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  section: {
    rowGap: 8,
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  title: {
    color: '#2D2D2D',
    fontSize: 14,
    lineHeight: 18,
    fontWeight: '600',
  },
  dateAction: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  dateActionText: {
    color: '#5676B3',
    fontSize: 12,
    lineHeight: 16,
    marginRight: 6,
  },
  card: {
    borderRadius: 5,
    backgroundColor: '#F0F7F0',
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 14,
  },
  topRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
  },
  usageLabel: {
    color: '#404840',
    fontSize: 11,
    lineHeight: 14,
  },
  usageRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
  },
  usageValue: {
    color: '#59B86E',
    fontSize: 14,
    lineHeight: 18,
    fontWeight: '700',
  },
  deltaPill: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 999,
    backgroundColor: '#59B86E',
    paddingHorizontal: 7,
    paddingVertical: 2,
    marginLeft: 6,
  },
  deltaText: {
    color: '#FFFFFF',
    fontSize: 9,
    lineHeight: 12,
    fontWeight: '700',
    marginRight: 2,
  },
  comparisonText: {
    color: '#505650',
    fontSize: 10,
    lineHeight: 13,
    marginLeft: 6,
  },
  chartButton: {
    height: 30,
    borderRadius: 3,
    backgroundColor: '#59B86E',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
  },
  chartButtonText: {
    color: '#FFFFFF',
    fontSize: 11,
    lineHeight: 14,
    fontWeight: '500',
    marginRight: 6,
  },
  rangeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 16,
    marginBottom: 16,
    paddingHorizontal: 6,
  },
  rangeText: {
    color: '#717771',
    fontSize: 11,
    lineHeight: 14,
    fontWeight: '600',
  },
  activeRangePill: {
    height: 26,
    minWidth: 66,
    borderRadius: 4,
    backgroundColor: '#24478E',
    alignItems: 'center',
    justifyContent: 'center',
  },
  activeRangeText: {
    color: '#FFFFFF',
    fontSize: 11,
    lineHeight: 14,
    fontWeight: '700',
  },
  chartWrap: {
    height: 176,
    justifyContent: 'flex-end',
  },
  dateModalBackdrop: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.35)',
    paddingHorizontal: 20,
  },
  dateModalCard: {
    borderRadius: 12,
    overflow: 'hidden',
  },
  dateModalActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 10,
  },
  dateActionButton: {
    minHeight: 32,
    justifyContent: 'center',
  },
  dateActionButtonText: {
    fontSize: 14,
    lineHeight: 18,
    fontWeight: '600',
  },
});
