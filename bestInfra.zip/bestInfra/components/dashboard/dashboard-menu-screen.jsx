import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { Image } from 'expo-image';
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { AnimatedRippleRings } from '../animated-ripple-rings';
import { DashboardAlertsTable } from './dashboard-alerts-table';
import { DashboardEnergySummary } from './dashboard-energy-summary';
import { DashboardMetricsComparison } from './dashboard-metrics-comparison';
import { DashboardOverviewSection } from './dashboard-overview-section';
import { getDashboardTheme } from './dashboard-theme';

const MENU_RIPPLE_SIZES = [64, 88, 112, 136, 160, 184, 208];
const PREVIEW_SCALE = 0.47;
const PREVIEW_BASE_WIDTH = 346;
const PREVIEW_BASE_HEIGHT = 1010;
const PREVIEW_OFFSET_X = -((PREVIEW_BASE_WIDTH - PREVIEW_BASE_WIDTH * PREVIEW_SCALE) / 2);
const PREVIEW_OFFSET_Y = -((PREVIEW_BASE_HEIGHT - PREVIEW_BASE_HEIGHT * PREVIEW_SCALE) / 2);

function MenuPreviewCard({ dashboardData }) {
  const previewTheme = getDashboardTheme('light');

  return (
    <View style={[styles.previewPhone, { backgroundColor: previewTheme.dashboardBackground }]}>
      <View style={styles.previewScaleFrame}>
        <View
          style={[
            styles.previewCanvas,
            {
              width: PREVIEW_BASE_WIDTH,
              height: PREVIEW_BASE_HEIGHT,
              backgroundColor: previewTheme.dashboardBackground,
              transform: [{ translateX: PREVIEW_OFFSET_X }, { translateY: PREVIEW_OFFSET_Y }, { scale: PREVIEW_SCALE }],
            },
          ]}>
          <AnimatedRippleRings
            color={previewTheme.rippleColor}
            sizes={[72, 104, 136, 168, 200, 232, 264, 296]}
            style={styles.previewRippleBackdrop}
          />

          <View style={styles.previewDashboardContent}>
            <DashboardOverviewSection
              data={dashboardData.overview}
              theme={previewTheme}
              onOpenMenu={() => {}}
              onOpenNotifications={() => {}}
            />
            <DashboardEnergySummary data={dashboardData.energySummary} theme={previewTheme} />
            <DashboardMetricsComparison data={dashboardData.metricSummary} theme={previewTheme} />
            <DashboardAlertsTable rows={dashboardData.alerts || []} theme={previewTheme} />
          </View>
        </View>
      </View>
    </View>
  );
}

function MenuIcon({ name, active, theme }) {
  const color = active ? theme.menuAccent : theme.menuInactive;

  return <MaterialIcons name={name} size={18} color={color} />;
}

export function DashboardMenuScreen({
  onClose,
  onOpenDashboard,
  onOpenNotifications,
  onOpenSettings,
  onOpenProfile,
  onLogout,
  sidePadding,
  insets,
  themeMode,
  menuData,
  profileData,
  dashboardData,
  showPreview = true,
}) {
  const horizontalPadding = Math.max(8, sidePadding - 6);
  const theme = getDashboardTheme(themeMode);
  const resolvedMenu = menuData || { items: [], footerItems: [] };
  const profileName = profileData?.name || resolvedMenu.userName || 'Best Infra User';
  const profileId = profileData?.customerId ? `ID: ${profileData.customerId}` : resolvedMenu.userId;
  const avatarText = profileName
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() || '')
    .join('') || 'BI';

  return (
    <View style={[styles.screen, { backgroundColor: theme.screenBackground }]}>
      <StatusBar style={theme.statusBar} translucent backgroundColor="transparent" />

      <AnimatedRippleRings color={theme.rippleColor} sizes={MENU_RIPPLE_SIZES} style={styles.rippleBackdrop}>
        <View pointerEvents="none" style={styles.rippleLogoWrap}>
          <Image source={require('../../assets/images/Logo (1).png')} style={styles.rippleLogo} contentFit="contain" />
        </View>
      </AnimatedRippleRings>

      <SafeAreaView edges={['top', 'bottom']} style={styles.safeArea}>
        <View style={[styles.content, { paddingHorizontal: horizontalPadding, paddingBottom: insets.bottom + 8 }]}>
          <View style={styles.topBar}>
            <TouchableOpacity
              style={[styles.activeCircleButton, { backgroundColor: theme.topButtonPrimary }]}
              activeOpacity={0.85}
              onPress={onClose}>
              <Image
                source={require('../../assets/images/bars-staggered 2.png')}
                style={styles.headerIcon}
                contentFit="contain"
              />
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.circleButton, { backgroundColor: theme.topButtonSurface }]}
              activeOpacity={0.85}
              onPress={onOpenNotifications}>
              <Image source={require('../../assets/images/bell 1.png')} style={styles.headerIcon} contentFit="contain" />
            </TouchableOpacity>
          </View>

          <TouchableOpacity
            style={[styles.profileCard, { backgroundColor: theme.cardBackground }]}
            activeOpacity={0.85}
            onPress={onOpenProfile}>
            <View style={[styles.avatar, { backgroundColor: theme.topButtonSurface }]}>
              <Text style={styles.avatarText}>{avatarText}</Text>
            </View>

            <View style={styles.profileTextWrap}>
              <Text numberOfLines={1} style={[styles.profileName, { color: theme.textPrimary }]}>
                {profileName}
              </Text>
              <Text numberOfLines={1} style={[styles.profileId, { color: theme.textSecondary }]}>
                {profileId}
              </Text>
            </View>
          </TouchableOpacity>

          <View style={styles.menuStage}>
            <View style={[styles.menuList, !showPreview && styles.menuListExpanded]}>
              <View>
                {resolvedMenu.items.map((item) => (
                  <TouchableOpacity
                    key={item.id}
                    style={styles.menuItem}
                    activeOpacity={0.85}
                    onPress={item.id === 'dashboard' ? onOpenDashboard : undefined}>
                    <MenuIcon name={item.icon} active={item.active} theme={theme} />
                    <Text
                      style={[
                        styles.menuLabel,
                        { color: item.active ? theme.menuActive : theme.menuInactive },
                        item.active && styles.menuLabelActive,
                      ]}>
                      {item.label}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            <View style={styles.footerBlock}>
              {resolvedMenu.footerItems.map((item) => (
                <TouchableOpacity
                  key={item.id}
                  style={styles.menuItem}
                  activeOpacity={0.85}
                  onPress={item.id === 'settings' ? onOpenSettings : item.id === 'logout' ? onLogout : undefined}>
                  <MenuIcon name={item.icon} active={false} theme={theme} />
                  <Text style={[styles.menuLabel, { color: theme.menuInactive }]}>{item.label}</Text>
                </TouchableOpacity>
              ))}

              <Text style={[styles.versionText, { color: theme.textMuted }]}>{resolvedMenu.version}</Text>
            </View>

            {showPreview ? (
              <View pointerEvents="none" style={styles.previewWrap}>
                <View style={[styles.previewShadowCard, { backgroundColor: theme.overlayPanel }]} />
                {dashboardData ? <MenuPreviewCard dashboardData={dashboardData} /> : null}
              </View>
            ) : null}
          </View>
        </View>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#143F93',
  },
  rippleBackdrop: {
    position: 'absolute',
    top: -8,
    left: 0,
    right: 0,
    height: 176,
  },
  rippleLogoWrap: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rippleLogo: {
    width: 38,
    height: 34,
  },
  safeArea: {
    flex: 1,
  },
  content: {
    flex: 1,
  },
  topBar: {
    height: 44,
    position: 'relative',
    marginTop: 10,
  },
  circleButton: {
    position: 'absolute',
    top: 0,
    right: 0,
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  activeCircleButton: {
    position: 'absolute',
    top: 0,
    left: 0,
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#5CBC70',
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerIcon: {
    width: 18,
    height: 18,
  },
  profileCard: {
    height: 54,
    borderRadius: 11,
    backgroundColor: 'rgba(255, 255, 255, 0.09)',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    marginTop: 14,
  },
  avatar: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: '#F4F7FB',
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    color: '#C7773E',
    fontSize: 12,
    lineHeight: 16,
    fontWeight: '700',
  },
  profileTextWrap: {
    marginLeft: 12,
    flex: 1,
  },
  profileName: {
    fontSize: 14,
    lineHeight: 18,
    fontWeight: '600',
    flexShrink: 1,
  },
  profileId: {
    fontSize: 10.5,
    lineHeight: 14,
    marginTop: 2,
    flexShrink: 1,
  },
  menuStage: {
    flex: 1,
    position: 'relative',
    marginTop: 10,
  },
  menuList: {
    width: '45%',
    paddingLeft: 0,
  },
  menuListExpanded: {
    width: '54%',
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    minHeight: 34,
    marginBottom: 10,
  },
  menuLabel: {
    fontSize: 15,
    lineHeight: 20,
    marginLeft: 12,
  },
  menuLabelActive: {
    fontWeight: '700',
  },
  footerBlock: {
    position: 'absolute',
    left: 0,
    bottom: 72,
    width: '45%',
  },
  versionText: {
    fontSize: 11,
    lineHeight: 14,
    marginTop: 4,
  },
  previewWrap: {
    position: 'absolute',
    top: 92,
    right: -56,
    width: 210,
    alignItems: 'flex-end',
  },
  previewShadowCard: {
    position: 'absolute',
    top: 118,
    left: -32,
    width: 370,
    height: 460,
    borderTopLeftRadius: 30,
    borderBottomLeftRadius: 30,
    borderTopRightRadius: 24,
    borderBottomRightRadius: 24,
    backgroundColor: 'rgba(108, 133, 183, 0.38)',
  },
  previewPhone: {
    width: 246,
    height: 543,
    borderTopLeftRadius: 26,
    borderBottomLeftRadius: 26,
    borderTopRightRadius: 28,
    borderBottomRightRadius: 28,
    backgroundColor: '#FFFFFF',
    overflow: 'hidden',
  },
  previewScaleFrame: {
    width: '100%',
    height: '100%',
    overflow: 'hidden',
    borderTopLeftRadius: 26,
    borderBottomLeftRadius: 26,
    borderTopRightRadius: 28,
    borderBottomRightRadius: 28,
    backgroundColor: '#F7F9F6',
  },
  previewCanvas: {
    position: 'absolute',
    top: 0,
    left: 0,
  },
  previewRippleBackdrop: {
    position: 'absolute',
    top: -86,
    left: '50%',
    width: 350,
    height: 330,
    marginLeft: -165,
    opacity: 0.62,
  },
  previewDashboardContent: {
    paddingTop: 12,
    paddingHorizontal: 13,
    rowGap: 12,
  },
});
